package dk.mwittrock.cpilint.model;

public enum ChannelDirection {
	
	SENDER,
	RECEIVER

}
