package dk.mwittrock.cpilint.rules.naming;

public interface NamingScheme {
	
	public boolean test(String name);

}
