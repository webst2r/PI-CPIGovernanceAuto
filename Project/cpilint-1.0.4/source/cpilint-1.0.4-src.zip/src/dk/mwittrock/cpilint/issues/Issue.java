package dk.mwittrock.cpilint.issues;

public interface Issue {
	
	public String getMessage();
	
}
