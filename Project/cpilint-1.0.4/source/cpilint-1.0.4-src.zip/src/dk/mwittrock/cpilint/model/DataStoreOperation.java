package dk.mwittrock.cpilint.model;

public enum DataStoreOperation {
	
	READ,
	WRITE,
	DELETE,
	SELECT

}
